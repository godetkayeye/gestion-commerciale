var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/location/locataires/[id]/historique/route.js")
R.c("server/chunks/[root-of-the-server]__f9866b02._.js")
R.c("server/chunks/2b794_next_f4e5050f._.js")
R.c("server/chunks/[root-of-the-server]__1c8121e2._.js")
R.c("server/chunks/gestion-commerciale_a47924d4._.js")
R.c("server/chunks/gestion-commerciale_a4eeef39._.js")
R.c("server/chunks/cf2b6_server_app_api_location_locataires_[id]_historique_route_actions_70c956a6.js")
R.m(28821)
module.exports=R.m(28821).exports
