var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/bar/commandes/[id]/facturer/route.js")
R.c("server/chunks/[root-of-the-server]__b69552e3._.js")
R.c("server/chunks/2b794_next_f4e5050f._.js")
R.c("server/chunks/gestion-commerciale_a4eeef39._.js")
R.c("server/chunks/gestion-commerciale_a47924d4._.js")
R.c("server/chunks/[root-of-the-server]__1c8121e2._.js")
R.c("server/chunks/2141b_next-internal_server_app_api_bar_commandes_[id]_facturer_route_actions_251efaeb.js")
R.m(46078)
module.exports=R.m(46078).exports
