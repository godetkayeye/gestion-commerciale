var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/bar/personnel/[id]/ventes/route.js")
R.c("server/chunks/[root-of-the-server]__73bb8516._.js")
R.c("server/chunks/2b794_next_f4e5050f._.js")
R.c("server/chunks/[root-of-the-server]__1c8121e2._.js")
R.c("server/chunks/gestion-commerciale_a4eeef39._.js")
R.c("server/chunks/5ade5__next-internal_server_app_api_bar_personnel_[id]_ventes_route_actions_5c92c9ec.js")
R.m(25370)
module.exports=R.m(25370).exports
