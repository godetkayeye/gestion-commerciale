var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/bar/factures/route.js")
R.c("server/chunks/[root-of-the-server]__77729b39._.js")
R.c("server/chunks/2b794_next_f4e5050f._.js")
R.c("server/chunks/[root-of-the-server]__1c8121e2._.js")
R.c("server/chunks/gestion-commerciale_a47924d4._.js")
R.c("server/chunks/gestion-commerciale_a4eeef39._.js")
R.c("server/chunks/5ade5__next-internal_server_app_api_bar_factures_route_actions_6b16dc52.js")
R.m(44474)
module.exports=R.m(44474).exports
